# Источники отелей и фотографий

Фотографии направлений: Unsplash, photo-1555881400-74d7acaacd8b (Португалия), photo-1516483638261-f4dbaf036963 (Италия), photo-1537996194471-e657df975ab4 (Бали), photo-1531366936337-7c912a4589a7 (Север). Фотографии и факты об отелях взяты с их официальных публичных страниц для демонстрационного концепта. Показанное фото не гарантирует конкретную категорию номера. Отели не заявлены как партнёры ROAM.

- PortoBay Flores: https://www.portobay.com/en/hotels/porto-hotels/portobay-flores/
- Torel Avantgarde: https://www.torelavantgarde.com/
- Hotel Porto Roca: https://www.portoroca.it/en/4-star-hotel-monterosso
- Hotel Marina: https://www.hotelmarina5terre.it/en/hotel/
- Wapa di Ume Ubud: https://wapadiumeubud.com/
- Adiwana Bisma: https://adiwanahotels.com/bisma-resort-ubud-bali/
- Sommarøy Arctic Hotel: https://www.sommaroy.no/
- Malangen Resort: https://www.malangenresort.com/

Сведения просмотрены 22 октября 2026 года. Программы путешествий и примеры дней — оригинальное иллюстративное содержание. Стоимость и доступность номеров не запрашивались.
