// A playful shortcut into the existing itineraries; never a booking or payment.
const surpriseDialog=document.querySelector('#surprise-dialog');
const ticketTrigger=document.querySelector('.surprise-trigger');
const ticketStage=document.querySelector('.ticket-stage');
const ticketAgain=document.querySelector('#surprise-again');
const ticketGo=document.querySelector('#surprise-go');
const ticketStatus=document.querySelector('#surprise-status');
const destinationCodes={italy:'ITA',bali:'BAL',norway:'NOR',portugal:'POR'};
let ticketChoice=null;
let ticketSequence=0;
const ticketPause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function drawTicket(){
  const sequence=++ticketSequence;
  const choices=stays.filter(stay=>stay.id!==ticketChoice?.id);
  const next=choices[Math.floor(Math.random()*choices.length)];
  ticketGo.disabled=true;ticketAgain.disabled=true;
  ticketStage.classList.add('is-picking');ticketStage.setAttribute('aria-busy','true');
  ticketStatus.textContent='Ищем направление для вашего следующего путешествия…';
  document.querySelector('#ticket-country').textContent='Пункт назначения — сюрприз';
  document.querySelector('#ticket-duration').textContent='Даты — под вас';
  const photo=document.querySelector('#ticket-photo');
  const preload=new Image();preload.src=`assets/${next.image}.webp`;
  const imageReady=preload.decode().catch(()=>{});
  if(!reduceMotion.matches){
    ticketStage.animate([{transform:'perspective(1000px) rotateX(8deg) scale(.96)',opacity:.65},{transform:'perspective(1000px) rotateX(0deg) scale(1)',opacity:1}],{duration:420,easing:'cubic-bezier(.2,.7,.25,1)'});
    const codes=['ROM','DPS','TOS','OPO'];
    for(let i=0;i<4;i++){
      if(sequence!==ticketSequence||!surpriseDialog.open)return;
      document.querySelector('#ticket-code').textContent=codes[i];
      await ticketPause(135+i*25);
    }
  }
  await imageReady;
  if(sequence!==ticketSequence||!surpriseDialog.open)return;
  ticketChoice=next;photo.src=preload.src;photo.alt=next.name+': пейзаж направления';
  document.querySelector('#ticket-code').textContent=destinationCodes[next.id];
  document.querySelector('#ticket-country').textContent=next.destination;
  document.querySelector('#ticket-duration').textContent=next.days+' / '+next.type;
  ticketStage.classList.remove('is-picking');ticketStage.setAttribute('aria-busy','false');
  ticketStatus.textContent='Ваше направление — '+next.destination+'. Посмотрим маршрут?';
  ticketGo.disabled=false;ticketAgain.disabled=false;
  if(!reduceMotion.matches){
    document.querySelector('.ticket-stamp').animate([{opacity:0,transform:'rotate(-25deg) scale(1.4)'},{opacity:1,transform:'rotate(-13deg) scale(1)'}],{duration:340,easing:'cubic-bezier(.2,.7,.25,1)'});
    document.querySelector('.ticket-airport').animate([{opacity:0,transform:'translateY(8px)'},{opacity:1,transform:'none'}],{duration:240,easing:'ease-out'});
  }
}
ticketTrigger.addEventListener('click',()=>{openDialog(surpriseDialog);drawTicket();});
ticketAgain.addEventListener('click',drawTicket);
ticketGo.addEventListener('click',()=>{if(!ticketChoice)return;const id=ticketChoice.id;surpriseDialog.close();showStay(id);focusReturn=ticketTrigger;});
surpriseDialog.addEventListener('close',()=>{ticketSequence++;ticketStage.setAttribute('aria-busy','false');});
